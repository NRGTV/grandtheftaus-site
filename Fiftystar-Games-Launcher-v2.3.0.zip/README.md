# Fiftystar Games Launcher

A Windows launcher for Grand Theft Aus 2. It installs from a local release folder or downloads from a public MEGA folder. Updates verify each file against the release manifest.

Version 2.3.0 adds automatic installation of game patch ZIPs through Check / Update. Upload `Grand-Theft-Aus-2-Audio-Patch-2.1.2.zip` to the shared MEGA folder alongside the existing game files. Keep its filename unchanged. Existing players using this launcher will download and install the newer patch without redownloading the full game. A patch requires a compatible installed game; new players still need the full release. The launcher checks archive paths, base assembly compatibility, file hashes and the resulting release manifest, then uses staged installation and rollback. A local patch ZIP path can also be pasted into the source field. Close the game before updating. The launcher itself must be replaced with this version once; older launchers cannot read patch ZIPs.

## Use

1. Extract this folder anywhere on Windows.
2. Open `Fiftystar Games Launcher.exe`.
3. The new game source is prefilled as `https://mega.nz/folder/4UVQWL7I#7oSHZsCOGhIsAHoWenSHVg`. Choose an install folder and select **Install Game**. The default is `%LOCALAPPDATA%\Fiftystar\Games\GTAus2`. Existing game install paths are imported from the previous launcher.
4. Select **Play** after installation. The F★ Games / Grand Theft Aus startup screen appears, then hands control to the game when Melbourne has loaded. Press **Esc** to continue directly to the game.
5. For a later release, close the game, select the release source and click **Check / Update**.

Open **Mods** in the left navigation to view installed mods, install a mod ZIP that contains `mod.cfg`, or open the game's mod folder.

The source field also accepts a local release folder. Share the folder containing `unity`, or the `unity` folder itself. The game executable and `update-manifest.json` belong directly inside `unity`. Upload all game files before uploading the manifest. Until the new upload is complete, the launcher shows a release-not-ready message and lets you try again later.

The launcher checks the size and SHA-256 of installed files, transfers changed files into a staging folder, then replaces the installed files and updates the installed manifest. Select **Redownload existing files (repair)** to force a fresh copy. The install drive needs space for the staged version of changed files. User-added files outside the release manifest are preserved. The launcher stores its install path and source in `%LOCALAPPDATA%\Fiftystar Games Launcher\settings.ini`.

## Build

The Unity project’s `Launcher` folder contains the source. Run `Build-Launcher.ps1` there in PowerShell to compile `Launcher.cs`, `GameUpdate.cs` and `BootScreen.cs` with the Windows .NET Framework C# compiler. Keep the two managed library DLLs and the artwork alongside the launcher executable. Run the EXE with `--preview-boot` to preview the startup screen for 12 seconds.

## Third-party components

- MegaApiClient 1.10.5 by Grégoire Pailler, MIT license: <https://github.com/gpailler/MegaApiClient>
- Newtonsoft.Json 10.0.2 by James Newton-King, MIT license: <https://github.com/JamesNK/Newtonsoft.Json>

The included `LICENSE.md` is the Newtonsoft.Json MIT license. MegaApiClient is distributed under MIT; its source and license are available at the link above.
