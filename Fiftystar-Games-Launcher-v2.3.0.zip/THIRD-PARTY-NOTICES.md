## MegaApiClient 1.10.5

Copyright (c) 2013-2024 Grégoire Pailler. MIT License.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

Source: https://github.com/gpailler/MegaApiClient

## Newtonsoft.Json 10.0.2

Copyright (c) 2007 James Newton-King. MIT License. The full license text is in `LICENSE.md`.

Source: https://github.com/JamesNK/Newtonsoft.Json
